
-- Switch to Staging Database
USE StagingCataschevastica;

--Delete all tables that already exist that were used for the first loading of data to the DW

-- Declare a variable to hold the dynamic SQL
DECLARE @sql NVARCHAR(MAX) = N'';

-- Generate the DROP TABLE statements for all tables
SELECT @sql += N'DROP TABLE ' + QUOTENAME(TABLE_SCHEMA) + '.' + QUOTENAME(TABLE_NAME) + ';' + CHAR(13)
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE';

-- Print the SQL statements for verification (optional)
PRINT @sql;

-- Execute the generated SQL statements
EXEC sp_executesql @sql;

----------------------------------------------------------------------------------------------------------------

-- TABLE Customer

--Create New Table
CREATE TABLE dbo.StagingCustomer (
    CustomerID INT,
    CustomerFirstName NVARCHAR(100),
    CustomerLastName NVARCHAR(100),
    CustomerPhoneNumber NVARCHAR(100),
    CustomerEmail NVARCHAR(255),
    Cust_RowVersion BINARY(8),
    RowChangeReason NVARCHAR(200)
);

-- Detect New Customers
INSERT INTO StagingCataschevastica.dbo.StagingCustomer (CustomerID, CustomerFirstName, CustomerLastName, CustomerPhoneNumber, CustomerEmail, Cust_RowVersion, RowChangeReason)
SELECT 
    c.CustomerID, 
    c.FirstName AS CustomerFirstName, 
    c.LastName AS CustomerLastName, 
    c.PhoneNumber AS CustomerPhoneNumber, 
    c.Email AS CustomerEmail,
    c.row_version AS Cust_RowVersion,
    'New' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.Customer c
LEFT JOIN CataschevasticaDW.dbo.DimCustomer dc ON c.CustomerID = dc.CustomerID
WHERE dc.CustomerID IS NULL;


-- Detect Updated Customers
INSERT INTO StagingCataschevastica.dbo.StagingCustomer (CustomerID, CustomerFirstName, CustomerLastName, CustomerPhoneNumber, CustomerEmail, Cust_RowVersion, RowChangeReason)
SELECT 
    c.CustomerID, 
    c.FirstName AS CustomerFirstName, 
    c.LastName AS CustomerLastName, 
    c.PhoneNumber AS CustomerPhoneNumber, 
    c.Email AS CustomerEmail,
    c.row_version AS Cust_RowVersion,
    'Updated' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.Customer c
INNER JOIN CataschevasticaDW.dbo.DimCustomer dc ON c.CustomerID = dc.CustomerID
WHERE dc.Cust_RowVersion <> c.row_version
AND dc.RowIsCurrent = 1;
GO

-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Mark Old Rows as Not Current
UPDATE dbo.DimCustomer
SET RowIsCurrent = 0, RowEndDate = SYSDATETIME()
FROM dbo.DimCustomer dc
INNER JOIN StagingCataschevastica.dbo.StagingCustomer suc ON dc.CustomerID = suc.CustomerID
WHERE dc.RowIsCurrent = 1;

-- Insert New and Updated Customers into Dimension Table
INSERT INTO dbo.DimCustomer (CustomerID, FirstName, LastName, PhoneNumber, Email, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason,Cust_RowVersion)
SELECT CustomerID, CustomerFirstName, CustomerLastName, CustomerPhoneNumber, CustomerEmail, 1, SYSDATETIME(), '9999-12-31', RowChangeReason,Cust_RowVersion
FROM StagingCataschevastica.dbo.StagingCustomer;


-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingCustomer;


----------------------------------------------------------------------------------------------------------------


-- Switch to Staging Database
USE StagingCataschevastica;
GO

-- TABLE LogisticsPartner

--Create New Table
CREATE TABLE dbo.StagingLogisticsPartner (
    LogisticID INT,
    LogPartFirstName NVARCHAR(100),
    LogPartLastName NVARCHAR(100),
    LogPartEmail NVARCHAR(255),
    Log_RowVersion BINARY(8),
    RowChangeReason NVARCHAR(200)
);


-- Detect New Logistics Partners
INSERT INTO StagingCataschevastica.dbo.StagingLogisticsPartner (LogisticID, LogPartFirstName, LogPartLastName, LogPartEmail, Log_RowVersion, RowChangeReason)
SELECT 
    lp.LogisticID, 
    lp.FirstName AS LogPartFirstName, 
    lp.LastName AS LogPartLastName, 
    lp.Email AS LogPartEmail,
    lp.row_version AS Log_RowVersion,
    'New' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.LogisticsPartner lp
LEFT JOIN CataschevasticaDW.dbo.DimLogisticsPartner dlp ON lp.LogisticID = dlp.LogisticID
WHERE dlp.LogisticID IS NULL;


-- Detect Updated Logistics Partners
INSERT INTO StagingCataschevastica.dbo.StagingLogisticsPartner (LogisticID, LogPartFirstName, LogPartLastName, LogPartEmail, Log_RowVersion, RowChangeReason)
SELECT 
    lp.LogisticID, 
    lp.FirstName AS LogPartFirstName, 
    lp.LastName AS LogPartLastName, 
    lp.Email AS LogPartEmail,
    lp.row_version AS Log_RowVersion,
    'Updated' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.LogisticsPartner lp
INNER JOIN CataschevasticaDW.dbo.DimLogisticsPartner dlp ON lp.LogisticID = dlp.LogisticID
WHERE dlp.Log_RowVersion <> lp.row_version
AND dlp.RowIsCurrent = 1;


-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Mark Old Rows as Not Current
UPDATE dbo.DimLogisticsPartner
SET RowIsCurrent = 0, RowEndDate = SYSDATETIME()
FROM dbo.DimLogisticsPartner dlp
INNER JOIN StagingCataschevastica.dbo.StagingLogisticsPartner slp ON dlp.LogisticID = slp.LogisticID
WHERE dlp.RowIsCurrent = 1;


-- Insert New and Updated Logistics Partners into Dimension Table
INSERT INTO dbo.DimLogisticsPartner (LogisticID, FirstName, LastName, Email, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason, Log_RowVersion)
SELECT LogisticID, LogPartFirstName, LogPartLastName, LogPartEmail, 1, SYSDATETIME(), '9999-12-31', RowChangeReason, Log_RowVersion
FROM StagingCataschevastica.dbo.StagingLogisticsPartner;
GO

-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingLogisticsPartner;
GO


----------------------------------------------------------------------------------------------------------------
-- Switch to Staging Database
USE StagingCataschevastica;

-- TABLE Production Team Member

--Create New Table
CREATE TABLE dbo.StagingProdTeamMember (
    MemberID NVARCHAR(100),
    MemberFirstName NVARCHAR(100),
    MemberLastName NVARCHAR(100),
    MemberEmail NVARCHAR(255),
    PTM_RowVersion BINARY(8),
    RowChangeReason NVARCHAR(200)
);


-- Detect New Production Team Members
INSERT INTO StagingCataschevastica.dbo.StagingProdTeamMember (MemberID, MemberFirstName, MemberLastName, MemberEmail, PTM_RowVersion, RowChangeReason)
SELECT 
    ptm.MemberID, 
    ptm.FirstName AS MemberFirstName, 
    ptm.LastName AS MemberLastName, 
    ptm.Email AS MemberEmail,
    ptm.row_version AS PTM_RowVersion,
    'New' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.ProdTeamMember ptm
LEFT JOIN CataschevasticaDW.dbo.DimProdTeamMember dptm ON ptm.MemberID = dptm.MemberID
WHERE dptm.MemberID IS NULL;


-- Detect Updated Production Team Members
INSERT INTO StagingCataschevastica.dbo.StagingProdTeamMember (MemberID, MemberFirstName, MemberLastName, MemberEmail, PTM_RowVersion, RowChangeReason)
SELECT 
    ptm.MemberID, 
    ptm.FirstName AS MemberFirstName, 
    ptm.LastName AS MemberLastName, 
    ptm.Email AS MemberEmail,
    ptm.row_version AS PTM_RowVersion,
    'Updated' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.ProdTeamMember ptm
INNER JOIN CataschevasticaDW.dbo.DimProdTeamMember dptm ON ptm.MemberID = dptm.MemberID
WHERE dptm.PTM_RowVersion <> ptm.row_version
AND dptm.RowIsCurrent = 1;


-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO


-- Mark Old Rows as Not Current
UPDATE dbo.DimProdTeamMember
SET RowIsCurrent = 0, RowEndDate = SYSDATETIME()
FROM dbo.DimProdTeamMember dptm
INNER JOIN StagingCataschevastica.dbo.StagingProdTeamMember sptm ON dptm.MemberID = sptm.MemberID
WHERE dptm.RowIsCurrent = 1;

-- Insert New and Updated Production Team Members into Dimension Table
INSERT INTO dbo.DimProdTeamMember (MemberID, FirstName, LastName, Email, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason, PTM_RowVersion)
SELECT MemberID, MemberFirstName, MemberLastName, MemberEmail, 1, SYSDATETIME(), '9999-12-31', RowChangeReason, PTM_RowVersion
FROM StagingCataschevastica.dbo.StagingProdTeamMember;

-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingProdTeamMember;


----------------------------------------------------------------------------------------------------------------

-- Switch to the Staging Database
USE StagingCataschevastica;
GO

-- TABLE Product

--Create New Table
CREATE TABLE dbo.StagingProduct (
    ProductID INT,
    ProductName NVARCHAR(100),
    SKU NVARCHAR(50),
    Length DECIMAL(10, 2),
    Width DECIMAL(10, 2),
    Thickness DECIMAL(10, 2),
    Weight DECIMAL(10, 2),
    ColorFinish NVARCHAR(100),
    Compliance NVARCHAR(100),
    CostPerUnit DECIMAL(10, 2),
    ConstructionTime DECIMAL(10, 2),
    Prod_RowVersion BINARY(8),
    RowChangeReason NVARCHAR(200)
);

-- Detect New Products
INSERT INTO StagingCataschevastica.dbo.StagingProduct (ProductID, ProductName, SKU, Length, Width, Thickness, Weight, ColorFinish, Compliance, CostPerUnit, ConstructionTime, Prod_RowVersion, RowChangeReason)
SELECT 
    p.ProductID, 
    p.Name AS ProductName, 
    p.SKU, 
    p.Length, 
    p.Width, 
    p.Thickness, 
    p.Weight, 
    p.ColorFinish, 
    p.Compliance, 
    p.CostPerUnit, 
    p.ConstructionTime,
    p.row_version AS Prod_RowVersion,
    'New' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.Product p
LEFT JOIN CataschevasticaDW.dbo.DimProduct dp ON p.ProductID = dp.ProductID
WHERE dp.ProductID IS NULL;

-- Detect Updated Products
INSERT INTO StagingCataschevastica.dbo.StagingProduct (ProductID, ProductName, SKU, Length, Width, Thickness, Weight, ColorFinish, Compliance, CostPerUnit, ConstructionTime, Prod_RowVersion, RowChangeReason)
SELECT 
    p.ProductID, 
    p.Name AS ProductName, 
    p.SKU, 
    p.Length, 
    p.Width, 
    p.Thickness, 
    p.Weight, 
    p.ColorFinish, 
    p.Compliance, 
    p.CostPerUnit, 
    p.ConstructionTime,
    p.row_version AS Prod_RowVersion,
    'Updated' AS RowChangeReason
FROM CataschevasticaNewVer.dbo.Product p
INNER JOIN CataschevasticaDW.dbo.DimProduct dp ON p.ProductID = dp.ProductID
WHERE dp.Prod_RowVersion <> p.row_version
AND dp.RowIsCurrent = 1;

-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Mark Old Rows as Not Current
UPDATE dbo.DimProduct
SET RowIsCurrent = 0, RowEndDate = SYSDATETIME()
FROM dbo.DimProduct dp
INNER JOIN StagingCataschevastica.dbo.StagingProduct sp ON dp.ProductID = sp.ProductID
WHERE dp.RowIsCurrent = 1;

-- Insert New and Updated Products into Dimension Table
INSERT INTO dbo.DimProduct (ProductID, ProductName, SKU, Length, Width, Thickness, Weight, ColorFinish, Compliance, CostPerUnit, ConstructionTime, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason, Prod_RowVersion)
SELECT ProductID, ProductName, SKU, Length, Width, Thickness, Weight, ColorFinish, Compliance, CostPerUnit, ConstructionTime, 1, SYSDATETIME(), '9999-12-31', RowChangeReason, Prod_RowVersion
FROM StagingCataschevastica.dbo.StagingProduct;

-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingProduct;
GO

----------------------------------------------------------------------------------------------------------------

-- Switch to the Staging Database
USE StagingCataschevastica;
GO

-- TABLE RawMaterial

--Create New Table
CREATE TABLE dbo.StagingRawMaterial (
    RawMaterialID INT,
    RawMaterialName NVARCHAR(100),
    MeasureUnit NVARCHAR(50),
    SupplierFirstName NVARCHAR(100),
    SupplierLastName NVARCHAR(100),
    SupplierEmail NVARCHAR(255),
    RM_RowVersion BINARY(8),
    RowChangeReason NVARCHAR(200)
);

-- Detect New Raw Materials
INSERT INTO StagingCataschevastica.dbo.StagingRawMaterial (RawMaterialID, RawMaterialName, MeasureUnit, SupplierFirstName, SupplierLastName, SupplierEmail, RM_RowVersion, RowChangeReason)
SELECT 
    rm.RawMaterialID, 
    rm.[Name] AS RawMaterialName, 
    rm.MeasureUnit,
    s.[FirstName] AS SupplierFirstName, 
    s.LastName AS SupplierLastName, 
    s.Email AS SupplierEmail,
    rm.row_version AS RM_RowVersion,
    'New' AS RowChangeReason
FROM CataschevasticaNewver.dbo.RawMaterial rm
LEFT JOIN CataschevasticaNewVer.dbo.Supplier s ON rm.SupplierID = s.SupplierID
LEFT JOIN CataschevasticaDW.dbo.DimRawMaterial drm ON rm.RawMaterialID = drm.RawMaterialID
WHERE drm.RawMaterialID IS NULL;

-- Detect Updated Raw Materials
INSERT INTO StagingCataschevastica.dbo.StagingRawMaterial (RawMaterialID, RawMaterialName, MeasureUnit, SupplierFirstName, SupplierLastName, SupplierEmail, RM_RowVersion, RowChangeReason)
SELECT 
    rm.RawMaterialID, 
    rm.[Name] AS RawMaterialName, 
    rm.MeasureUnit,
    s.[FirstName] AS SupplierFirstName, 
    s.LastName AS SupplierLastName, 
    s.Email AS SupplierEmail,
    rm.row_version AS RM_RowVersion,
    'Updated' AS RowChangeReason
FROM CataschevasticaNewver.dbo.RawMaterial rm
LEFT JOIN CataschevasticaNewVer.dbo.Supplier s ON rm.SupplierID = s.SupplierID
INNER JOIN CataschevasticaDW.dbo.DimRawMaterial drm ON rm.RawMaterialID = drm.RawMaterialID
WHERE drm.RM_RowVersion <> rm.row_version
AND drm.RowIsCurrent = 1;

-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Mark Old Rows as Not Current
UPDATE dbo.DimRawMaterial
SET RowIsCurrent = 0, RowEndDate = SYSDATETIME()
FROM dbo.DimRawMaterial drm
INNER JOIN StagingCataschevastica.dbo.StagingRawMaterial srm ON drm.RawMaterialID = srm.RawMaterialID
WHERE drm.RowIsCurrent = 1;

-- Insert New and Updated Raw Materials into Dimension Table
INSERT INTO dbo.DimRawMaterial (RawMaterialID, RawMaterialName, MeasureUnit, SupplierFirstName, SupplierLastName, SupplierEmail, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason, RM_RowVersion)
SELECT RawMaterialID, RawMaterialName, MeasureUnit, SupplierFirstName, SupplierLastName, SupplierEmail, 1, SYSDATETIME(), '9999-12-31', RowChangeReason, RM_RowVersion
FROM StagingCataschevastica.dbo.StagingRawMaterial;
GO

-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingRawMaterial;
GO


----------------------------------------------------------------------------------------------------------------

-- Switch to the Staging Database
USE StagingCataschevastica;
GO


-- TABLE OrderDetails

--Create New Table
CREATE TABLE dbo.StagingOrderDetails (
    OrderDetailID INT,
    OrderID INT,
    CustomerID INT,
    OrderDate DATETIME,
    OrderStatus NVARCHAR(50),
    LogisticID INT,
    MemberID NVARCHAR(100),
    ProductID INT,
    OrderQuantity INT,
    -- Exclude Order_RowVersion as it is a timestamp
    CancellationDate DATETIME,
    CompletionDate DATETIME,
    DeliveryDate DATETIME,
    );

-- Detect New Order Details
INSERT INTO StagingCataschevastica.dbo.StagingOrderDetails (OrderDetailID, OrderID, CustomerID, OrderDate, OrderStatus, LogisticID, MemberID, ProductID, OrderQuantity, CancellationDate, CompletionDate, DeliveryDate)
SELECT 
    od.OrderDetailID,
    od.OrderID, 
    o.CustomerID,
    o.OrderDate,
    o.[Status] AS OrderStatus, 
    o.LogisticID, 
    o.MemberID, 
    od.ProductID, 
    od.Quantity AS OrderQuantity,
    o.CancellationDate,
    o.CompletionDate,
    o.DeliveryDate
FROM CataschevasticaNewVer.dbo.OrderDetails od
LEFT JOIN CataschevasticaNewVer.dbo.[Order] o ON od.OrderID = o.OrderID
LEFT JOIN CataschevasticaDW.dbo.FactOrderDetails fod ON od.OrderDetailID = fod.OrderDetailID
WHERE fod.OrderDetailID IS NULL;
GO


-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Insert New and Updated Order Details into Fact Table
INSERT INTO dbo.FactOrderDetails (
    CustomerKey, 
    OrderDateKey, 
    CompletionDateKey, 
    DeliveryDateKey, 
    CancellationDateKey, 
    OrderID, 
    OrderDetailID, 
    OrderStatus, 
    ProdTeamMemberKey, 
    LogisticsPartnerKey, 
    Quantity, 
    Order_RowVersion,
    ProductKey
)
SELECT 
    dc.CustomerKey,
    dd.DateKey AS OrderDateKey,
    dd2.DateKey AS CompletionDateKey,
    dd3.DateKey AS DeliveryDateKey,
    dd4.DateKey AS CancellationDateKey,
    sod.OrderID,
    sod.OrderDetailID,
    sod.OrderStatus,
    dptm.ProdTeamMemberKey,
    dlp.LogisticsPartnerKey,
    sod.OrderQuantity,
    o.row_version AS Order_RowVersion,
    dp.ProductKey
FROM StagingCataschevastica.dbo.StagingOrderDetails sod
LEFT JOIN CataschevasticaDW.dbo.DimCustomer dc ON sod.CustomerID = dc.CustomerID
LEFT JOIN CataschevasticaDW.dbo.DimDate dd ON CAST(sod.OrderDate AS DATE) = dd.Date
LEFT JOIN CataschevasticaDW.dbo.DimDate dd2 ON CAST(sod.CompletionDate AS DATE) = dd2.Date
LEFT JOIN CataschevasticaDW.dbo.DimDate dd3 ON CAST(sod.DeliveryDate AS DATE) = dd3.Date
LEFT JOIN CataschevasticaDW.dbo.DimDate dd4 ON CAST(sod.CancellationDate AS DATE) = dd4.Date
LEFT JOIN CataschevasticaNewVer.dbo.[Order] o ON sod.OrderID = o.OrderID -- Join to get the row_version
LEFT JOIN CataschevasticaDW.dbo.DimProdTeamMember dptm ON sod.MemberID = dptm.MemberID
LEFT JOIN CataschevasticaDW.dbo.DimLogisticsPartner dlp ON sod.LogisticID = dlp.LogisticID
LEFT JOIN CataschevasticaDW.dbo.DimProduct dp ON sod.ProductID = dp.ProductID; -- Join to get the ProductKey

-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingOrderDetails;
GO


----------------------------------------------------------------------------------------------------------------

-- Switch to the Staging Database
USE StagingCataschevastica;
GO


-- TABLE Production

--Create New Table
CREATE TABLE dbo.StagingProduction (
    ProductionID INT,
    ProductID INT,
    ProductionCompletionDate DATETIME,
    ProducedQuantity INT,
    TotalCost DECIMAL(10, 2),
    -- Exclude p_RowVersion as it is a timestamp
);


-- Detect New Production Records
INSERT INTO StagingCataschevastica.dbo.StagingProduction (ProductionID, ProductID, ProductionCompletionDate, ProducedQuantity, TotalCost)
SELECT
    p.ProductionID,
    p.ProductID,
    p.ProductionCompletionDate,
    p.Quantity AS ProducedQuantity,
    p.TotalCost
FROM CataschevasticaNewVer.dbo.Production p
LEFT JOIN CataschevasticaDW.dbo.FactProductionCompletion fp ON p.ProductionID = fp.ProductionID
WHERE fp.ProductionID IS NULL;
GO

-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Insert New Production Records into Fact Table
INSERT INTO FactProductionCompletion (
    ProductionID,                   
    ProductKey,                 
    ProductionCompletionDateKey, 
    ProducedQuantity,           
    TotalCost,
    p_RowVersion
)
SELECT 
    stagingProd.ProductionID,                 
    dimProd.ProductKey,                   
    dimDate.DateKey AS ProductionCompletionDateKey, 
    stagingProd.ProducedQuantity,         
    stagingProd.TotalCost,
    prod.row_version AS p_RowVersion -- Include p_RowVersion here
FROM  StagingCataschevastica.dbo.StagingProduction stagingProd
    -- Join with product dimension table to get ProductKey
     INNER JOIN DimProduct dimProd ON stagingProd.ProductID = dimProd.ProductID
    -- Join with date dimension table to get ProductionCompletionDateKey
     INNER JOIN DimDate dimDate ON CAST(stagingProd.ProductionCompletionDate AS DATE) = dimDate.Date
    -- Join to get the p_RowVersion from the original Production table
     INNER JOIN CataschevasticaNewVer.dbo.Production prod ON stagingProd.ProductionID = prod.ProductionID;
GO

-- Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingProduction;
GO

----------------------------------------------------------------------------------------------------------------

-- Switch to the Staging Database
USE StagingCataschevastica;
GO


-- TABLE Supply

--Create New Table
CREATE TABLE dbo.StagingSupply (
    SupplyID INT,
    SupplierID INT,
    RawMaterialID INT,
    SupplyDate DATETIME,
    Quantity INT,
    Cost DECIMAL(10, 2),
	TotalCost AS (Quantity * Cost) PERSISTED
);
GO


-- Insert new records into the Staging Table
INSERT INTO StagingCataschevastica.dbo.StagingSupply (SupplyID,SupplierID, RawMaterialID, SupplyDate, Quantity, Cost)
SELECT 
    s.SupplyID,
	s.SupplierID,
    s.RawMaterialID,
    s.SupplyDate,
    s.Quantity,
    s.Cost
FROM CataschevasticaNewVer.dbo.Supply s
LEFT JOIN CataschevasticaDW.dbo.FactSupply fs ON s.SupplyID = fs.SupplyID
WHERE fs.SupplyID IS NULL;


-- Switch to Data Warehouse Database
USE CataschevasticaDW;
GO

-- Insert new records into the Fact Table
INSERT INTO FactSupply (
    SupplyID,
    RawMaterialKey,
    SupplyDateKey,
    Quantity,
    Cost,
    s_RowVersion
)
SELECT 
    s.SupplyID,                 
    dimRawMaterial.RawMaterialKey,            
    dimDate.DateKey AS SupplyDateKey, 
    s.Quantity,         
    s.Cost,
    sup.row_version AS s_RowVersion -- Include p_RowVersion here
FROM 
    StagingCataschevastica.dbo.StagingSupply s
    INNER JOIN DimRawMaterial dimRawMaterial ON s.RawMaterialID = dimRawMaterial.RawMaterialID
    INNER JOIN DimDate dimDate ON CAST(s.SupplyDate AS DATE) = dimDate.Date
	-- Join to get the p_RowVersion from the original Production table
    INNER JOIN CataschevasticaNewVer.dbo.Supply sup ON s.SupplyID = sup.SupplyID;
GO


--Clean Up Staging Tables
TRUNCATE TABLE StagingCataschevastica.dbo.StagingSupply;
GO










