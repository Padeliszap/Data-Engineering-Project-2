# Databricks notebook source
# MAGIC %md
# MAGIC ## **Set the data location and type**

# COMMAND ----------

# Set Azure Blob Storage container name and account key
storage_account_name = 'blobcontainerdemo2'
storage_account_access_key = '9C7ID0teEFbe0kYRWcHeLAvBMD/3AU1lW8HAW4SGiEag2LzVgcSssIGLVRxykIsBZ41sZI8at+xP+ASttq0KSA=='
spark.conf.set('fs.azure.account.key.' + storage_account_name + '.blob.core.windows.net', storage_account_access_key)


# COMMAND ----------

# MAGIC %md 
# MAGIC ## **Define File Paths for CSV Files**

# COMMAND ----------

# File paths for dimensional tables
blob_container = 'blobcontainer'
filePath_1 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/DimCustomer.csv"
filePath_2 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/DimDate.csv"
filePath_3 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/DimLogisticsPartner.csv"
filePath_4 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/DimProduct.csv"
filePath_5 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/DimProdMember.csv"
filePath_6 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/DimRawMaterial.csv"
filePath_7 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/FactOrderDetails.csv"
filePath_8 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/FactProductionCompletion.csv"
filePath_9 = "wasbs://" + blob_container + "@" + storage_account_name + ".blob.core.windows.net/FactSupply.csv"


# COMMAND ----------

# MAGIC %md
# MAGIC ## **Load CSV Files into DataFrames**

# COMMAND ----------

# MAGIC %md 1. For Dimensional Tables

# COMMAND ----------

# Load CSV files into DataFrames for Dimensional Tables

Dim_CustomerDf = spark.read.format("csv").load(filePath_1, inferSchema = True, header = True)
Dim_DateDf = spark.read.format("csv").load(filePath_2, inferSchema = True, header = True)
Dim_LogisticsPartnerDf = spark.read.format("csv").load(filePath_3, inferSchema = True, header = True)
Dim_ProductDf = spark.read.format("csv").load(filePath_4, inferSchema = True, header = True)
Dim_ProdMemberDf = spark.read.format("csv").load(filePath_5, inferSchema = True, header = True)
Dim_RawMaterialDf = spark.read.format("csv").load(filePath_6, inferSchema = True, header = True)

# COMMAND ----------

# MAGIC
# MAGIC %md 2. For Fact Tables

# COMMAND ----------

# Load CSV files into DataFrames for Fact Tables
Fact_OrderDetailsDf = spark.read.format("csv").load(filePath_7, inferSchema = True, header = True)
Fact_ProductionCompletionDf = spark.read.format("csv").load(filePath_8, inferSchema = True, header = True)
Fact_SupplyDf = spark.read.format("csv").load(filePath_9, inferSchema = True, header = True)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ## **Display Dimensional & Fact Tables**

# COMMAND ----------

# MAGIC %md 1. For Dimensional Tables

# COMMAND ----------

# Display Dimensional Tables 
display(Dim_CustomerDf)
display(Dim_DateDf)
display(Dim_LogisticsPartnerDf)
display(Dim_ProductDf)
display(Dim_ProdMemberDf)
display(Dim_RawMaterialDf)

# COMMAND ----------

# Display Fact Tables 
display(Fact_OrderDetailsDf)
display(Fact_ProductionCompletionDf)
display(Fact_SupplyDf)


# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ## **Parquet Files & Datalake Creation**

# COMMAND ----------

# MAGIC %md 1. Defining paths for saving Dataframes with Parquet format

# COMMAND ----------

# Define Azure Blob Storage container and account information
storage_account_name = 'blobcontainerdemo2'
container_name = 'blobcontainer'

# Define paths for each DataFrame to save in Parquet format
save_paths = {
    "DimCustomer1": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/DimCustomer1",
    "DimDate2": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/DimDate2",
    "DimLogisticsPartner3": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/DimLogisticsPartner3",
    "DimProduct4": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/DimProduct4",
    "DimProdMember5": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/DimProdMember5",
    "DimRawMaterial6": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/DimRawMaterial6",
    "FactOrderDetails1": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/FactOrderDetails1",
    "FactProductionCompletion2": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/FactProductionCompletion2",
    "FactSupply3": "wasbs://" + container_name + "@" + storage_account_name + ".blob.core.windows.net/FactSupply3"
}


# COMMAND ----------

# MAGIC
# MAGIC %md 2. Writing Dataframes with Parquet format in Azure Data Lake

# COMMAND ----------

# Save DataFrames as tables in Parquet format in Azure Data Lake 
Dim_CustomerDf.write.format("parquet").mode("overwrite").save(save_paths["DimCustomer1"])
Dim_DateDf.write.format("parquet").mode("overwrite").save(save_paths["DimDate2"])
Dim_LogisticsPartnerDf.write.format("parquet").mode("overwrite").save(save_paths["DimLogisticsPartner3"])
Dim_ProductDf.write.format("parquet").mode("overwrite").save(save_paths["DimProduct4"])
Dim_ProdMemberDf.write.format("parquet").mode("overwrite").save(save_paths["DimProdMember5"])
Dim_RawMaterialDf.write.format("parquet").mode("overwrite").save(save_paths["DimRawMaterial6"])
Fact_OrderDetailsDf.write.format("parquet").mode("overwrite").save(save_paths["FactOrderDetails1"])
Fact_ProductionCompletionDf.write.format("parquet").mode("overwrite").save(save_paths["FactProductionCompletion2"])
Fact_SupplyDf.write.format("parquet").mode("overwrite").save(save_paths["FactSupply3"])

print("Data written to DataLake successfully.")

# COMMAND ----------

# MAGIC
# MAGIC %md 3. Read Parquet files from Azure Datalake

# COMMAND ----------

# Read Parquet files from Azure Data Lake into DataFrames
Dim_CustomerDf_from_lake = spark.read.parquet(save_paths["DimCustomer1"])
Dim_DateDf_from_lake = spark.read.parquet(save_paths["DimDate2"])
Dim_LogisticsPartnerDf_from_lake = spark.read.parquet(save_paths["DimLogisticsPartner3"])
Dim_ProductDf_from_lake = spark.read.parquet(save_paths["DimProduct4"])
Dim_ProdMemberDf_from_lake = spark.read.parquet(save_paths["DimProdMember5"])
Dim_RawMaterialDf_from_lake = spark.read.parquet(save_paths["DimRawMaterial6"])
Fact_OrderDetailsDf_from_lake = spark.read.parquet(save_paths["FactOrderDetails1"])
Fact_ProductionCompletionDf_from_lake = spark.read.parquet(save_paths["FactProductionCompletion2"])
Fact_SupplyDf_from_lake = spark.read.parquet(save_paths["FactSupply3"])

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ## **Performing Analytical & Visualization Operations**

# COMMAND ----------

# MAGIC %md
# MAGIC %md 1. Sales Per Customer

# COMMAND ----------

from pyspark.sql.functions import sum

# Calculate Sales per Customer
sales_per_customer = (
    Fact_OrderDetailsDf_from_lake.join(
        Dim_CustomerDf_from_lake, 
        Fact_OrderDetailsDf_from_lake["CustomerKey"] == Dim_CustomerDf_from_lake["CustomerKey"]
    )
   .groupBy(
        Dim_CustomerDf_from_lake["CustomerKey"],
        "FirstName",
        "LastName"
    )  
   .agg(
        sum(Fact_OrderDetailsDf_from_lake["Quantity"]).alias("TotalSales")
    )
)

# Show the result
sales_per_customer.show()


# COMMAND ----------

# import required libraries
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# Sort the DataFrame by 'TotalSales' in descending order
sales_per_customer_pd = sales_per_customer_pd.sort_values(by='TotalSales', ascending=False)

# Create the bBar Plot
plt.figure(figsize=(10, 8))
sns.barplot(x='TotalSales', y=sales_per_customer_pd['FirstName'] + ' ' + sales_per_customer_pd['LastName'], data=sales_per_customer_pd, palette='viridis')
plt.xlabel('Total Sales')
plt.ylabel('Customer Name')
plt.title('Total Sales per Customer (Ordered by Sales)')

plt.tight_layout()

# Show the plot
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC %md 2. Sales Per Product

# COMMAND ----------

# Calculate Sales per Product

# Sales per Product
sales_per_product = (
    Fact_OrderDetailsDf_from_lake.join(
        Dim_ProductDf_from_lake,
        Fact_OrderDetailsDf_from_lake["ProductKey"] == Dim_ProductDf_from_lake["ProductKey"]
    )
    .groupBy(
        Dim_ProductDf_from_lake["ProductKey"],
        Dim_ProductDf_from_lake["ProductName"]
    )
    .agg(
        sum(Fact_OrderDetailsDf_from_lake["Quantity"]).alias("TotalSales")
    )
)

# Show the result
sales_per_product.show()


# COMMAND ----------

#import seaborn library
import seaborn as sns

# Sort the DataFrame by 'TotalSales' in descending order
sales_per_product_pd = sales_per_product_pd.sort_values(by='TotalSales', ascending=False)

# Create the bar plot using Seaborn
plt.figure(figsize=(10, 8))
sns.barplot(x='TotalSales', y='ProductName', data=sales_per_product_pd, palette='viridis')
plt.xlabel('Total Sales')
plt.ylabel('Product Name')
plt.title('Total Sales per Product (Ordered by Sales)')

# Adjust layout to prevent labels from being cut off
plt.tight_layout()

# Show the plot
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC %md 3. Sales Per Date

# COMMAND ----------

from pyspark.sql.functions import sum

# Calculate Sales per Date using OrderDateKey
sales_per_date = (
    Fact_OrderDetailsDf_from_lake.join(
        Dim_DateDf_from_lake,
        Fact_OrderDetailsDf_from_lake["OrderDateKey"] == Dim_DateDf_from_lake["DateKey"]
    )
    .groupBy(
        Dim_DateDf_from_lake["Date"]
    )
    .agg(
        sum(Fact_OrderDetailsDf_from_lake["Quantity"]).alias("TotalSales")
    )
)

# Show the result
sales_per_date.show()



# COMMAND ----------

#Convert Spark DataFrame to Pandas DataFrame
sales_per_date_pd = sales_per_date.toPandas()


# Convert 'Date' column to datetime type
sales_per_date_pd['Date'] = pd.to_datetime(sales_per_date_pd['Date'])

# Sort by Date
sales_per_date_pd.sort_values(by='Date', inplace=True)

# Set the plot style using Seaborn
sns.set(style="whitegrid")

# Line Chart of Sales Trend Over Time
plt.figure(figsize=(12, 6))
plt.plot(sales_per_date_pd['Date'], sales_per_date_pd['TotalSales'], marker='o', color='b', linestyle='-')
plt.xlabel('Date')
plt.ylabel('Total Sales')
plt.title('Sales Trend Over Time')

# Emphasize peak sales
peak_sales = sales_per_date_pd['TotalSales'].max()
plt.axhline(y=peak_sales, color='r', linestyle='--', label=f'Peak Sales: {peak_sales:.0f}')

plt.xticks(rotation=0)  # Rotate x-axis labels to 0 degrees (horizontal)
plt.tight_layout()
plt.grid(True)  # Add grid lines for better readability

# Show legend
plt.legend()

# Show the plot
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC This table will persist across cluster restarts and allow various users across different notebooks to query this data.
