-- Create the staging database
CREATE DATABASE StagingCataschevastica;
GO

-- Switch to the staging database
USE StagingCataschevastica;
GO

-- Staging table for Customer
SELECT 
    CustomerID, 
    FirstName AS CustomerFirstName, 
    LastName AS CustomerLastName, 
    PhoneNumber AS CustomerPhoneNumber, 
    Email AS CustomerEmail,
    row_version AS Cust_RowVersion
INTO StagingCustomer
FROM CataschevasticaNewVer.dbo.Customer;

-- Staging table for LogisticPartner
SELECT 
    LogisticID, 
    FirstName as LogPartFirstName, 
    LastName as LogPartLastName, 
    Email as LogPartEmail,
	row_version AS Log_RowVersion
INTO StagingLogisticsPartner
FROM CataschevasticaNewVer.dbo.LogisticsPartner;


-- Staging table for ProdTeamMember
SELECT 
    MemberID, 
    FirstName as MemberFirstName, 
    LastName as MemberLastName, 
    Email as MemberEmail,
	row_version AS PTM_RowVersion
INTO StagingProdTeamMember
FROM CataschevasticaNewVer.dbo.ProdTeamMember;


-- Staging table for Product
SELECT 
    p.ProductID, 
    p.Name AS ProductName, 
    p.SKU, 
    p.Length, 
    p.Width, 
    p.Thickness, 
    p.Weight, 
    p.ColorFinish, 
    p.Compliance, 
    p.CostPerUnit, 
    p.ConstructionTime,
	row_version AS Prod_RowVersion
INTO StagingProduct
FROM CataschevasticaNewVer.dbo.Product p;


-- Staging table for RawMaterial
SELECT 
    rm.RawMaterialID, 
    rm.[Name] AS RawMaterialName, 
    rm.MeasureUnit,
    s.[FirstName] AS SupplierFirstName, 
    s.LastName AS SupplierLastName, 
    s.Email AS SupplierEmail,
	s.row_version AS RM_RowVersion
INTO StagingRawMaterial
FROM CataschevasticaNewver.dbo.RawMaterial rm
LEFT JOIN CataschevasticaNewVer.dbo.Supplier s ON rm.SupplierID = s.SupplierID;


-- Staging table for ProductRawMaterial
SELECT 
    prm.ProductID, 
    prm.RawMaterialID, 
    prm.Quantity,
	prm.row_version as PRM_RowVersion
INTO StagingProductRawMaterial
FROM CataschevasticaNewVer.dbo.ProductRawMaterial prm;


-- Staging table for OrderDetails
SELECT 
    od.OrderDetailID,
    od.OrderID, 
    o.CustomerID,
    o.OrderDate,
    o.[Status] AS OrderStatus, 
    o.LogisticID, 
    o.MemberID, 
    od.ProductID, 
    od.Quantity AS OrderQuantity,
	o.row_version AS Order_RowVersion,
    o.CancellationDate,
    o.CompletionDate,
    o.DeliveryDate
INTO StagingOrderDetails
FROM CataschevasticaNewVer.dbo.OrderDetails od
LEFT JOIN CataschevasticaNewVer.dbo.[Order] o ON od.OrderID = o.OrderID;


-- Staging table for Production
SELECT 
    p.ProductionID,
    p.OrderID,
    p.ProductID,
    p.ProductionCompletionDate,
    p.Quantity AS ProducedQuantity,
    p.TotalCost,
	p.row_version as p_RowVersion
INTO StagingProduction
FROM CataschevasticaNewVer.dbo.Production p;

-- Staging table for Supply
SELECT 
	s.SupplyID, 
    s.SupplierID ,
    s.RawMaterialID, 
    s.SupplyDate, 
    s.Quantity, 
    s.Cost,
	s.row_version as s_RowVersion
INTO StagingSupply
FROM CataschevasticaNewVer.dbo.Supply s;





