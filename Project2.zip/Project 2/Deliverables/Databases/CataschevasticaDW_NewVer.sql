
-- Create the DW database
CREATE DATABASE CataschevasticaDW;
GO

USE CataschevasticaDW;
GO

-- Dimension Tables

-- DimCustomer Table
CREATE TABLE DimCustomer (
    CustomerKey INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    PhoneNumber NVARCHAR(100),
    Email NVARCHAR(255) NOT NULL,
    RowIsCurrent BIT DEFAULT 1 NOT NULL,
    RowStartDate DATETIME2 DEFAULT SYSDATETIME(),
    RowEndDate DATETIME2 DEFAULT('9999-12-31'),
    RowChangeReason VARCHAR(200),
	Cust_RowVersion BINARY(8)
);


-- DimLogisticsPartner Table
CREATE TABLE DimLogisticsPartner (
    LogisticsPartnerKey INT IDENTITY(1,1) PRIMARY KEY,
    LogisticID INT NOT NULL,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) NOT NULL,
    RowIsCurrent BIT DEFAULT 1 NOT NULL,
    RowStartDate DATETIME2 DEFAULT SYSDATETIME(),
    RowEndDate DATETIME2 DEFAULT('9999-12-31'),
    RowChangeReason VARCHAR(200),
	Log_RowVersion BINARY(8)
);


-- DimProdTeamMember Table
CREATE TABLE DimProdTeamMember (
    ProdTeamMemberKey INT IDENTITY(1,1) PRIMARY KEY,
    MemberID NVARCHAR(100) NOT NULL,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) NOT NULL,
    RowIsCurrent BIT DEFAULT 1 NOT NULL,
    RowStartDate DATETIME2 DEFAULT SYSDATETIME(),
    RowEndDate DATETIME2 DEFAULT('9999-12-31'),
    RowChangeReason VARCHAR(200),
	PTM_RowVersion BINARY(8)
);

-- DimProduct Table
CREATE TABLE DimProduct (
    ProductKey INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    ProductName NVARCHAR(100) NOT NULL,
    SKU NVARCHAR(50) UNIQUE NOT NULL,
    [Length] DECIMAL(10, 2),
    Width DECIMAL(10, 2),
    Thickness DECIMAL(10, 2),
    [Weight] DECIMAL(10, 2),
    ColorFinish NVARCHAR(50),
    Compliance NVARCHAR(255) NOT NULL,
    CostPerUnit DECIMAL(10, 2) NOT NULL,
    ConstructionTime INT NOT NULL,
    RowIsCurrent BIT DEFAULT 1 NOT NULL,
    RowStartDate DATETIME2 DEFAULT SYSDATETIME(),
    RowEndDate DATETIME2 DEFAULT('9999-12-31'),
    RowChangeReason VARCHAR(200),
	Prod_RowVersion BINARY(8)
);

-- DimRawMaterial Table
CREATE TABLE DimRawMaterial (
    RawMaterialKey INT IDENTITY(1,1) PRIMARY KEY,
    RawMaterialID INT NOT NULL,
    RawMaterialName  NVARCHAR(100),
    MeasureUnit NVARCHAR(50),
    SupplierFirstName NVARCHAR(100),
    SupplierLastName NVARCHAR(100),
    SupplierEmail NVARCHAR(100),
    RowIsCurrent BIT DEFAULT 1 NOT NULL,
    RowStartDate DATETIME2 DEFAULT SYSDATETIME(),
    RowEndDate DATETIME2 DEFAULT('9999-12-31'),
    RowChangeReason VARCHAR(200),
	RM_RowVersion BINARY(8)
);


-- DimDate Table
CREATE TABLE DimDate (
        DateKey INT IDENTITY(1,1) PRIMARY KEY,
        Date DATE,
        Year INT,
        Quarter CHAR(1),
        Month INT,
        Day INT,
        GreekHoliday BIT DEFAULT 0
    );


-- FactOrderDetails Table 
CREATE TABLE FactOrderDetails (
    OrderDetailKey INT IDENTITY(1,1) PRIMARY KEY, -- surrogate key
    CustomerKey INT NOT NULL, -- Foreign key to DimCustomer
    OrderDateKey INT NOT NULL, -- Foreign key to DimDate
    CompletionDateKey INT, -- Foreign key to DimDate
    DeliveryDateKey INT, -- Foreign key to DimDate
    CancellationDateKey INT, -- Foreign key to DimDate
    OrderID INT NOT NULL, -- Natural key from OLTP for traceability
    OrderDetailID INT NOT NULL, -- Natural key from OLTP for traceability
    ProductKey INT NOT NULL, -- Foreign key to DimProduct
    OrderStatus NVARCHAR(50), -- Status of the order
    ProdTeamMemberKey INT, -- Foreign key to DimProdTeamMember
    LogisticsPartnerKey INT, -- Foreign key to DimLogisticsPartner
    Quantity INT, -- Quantity of products
    ExtendedPriceAmount FLOAT, -- Calculated price
    Order_RowVersion BINARY(8) -- Row Version method to track changes
);


-- FactProductionCompletion Table
CREATE TABLE FactProductionCompletion (
    ProductionKey INT IDENTITY(1,1) PRIMARY KEY,
    ProductionID INT NOT NULL, -- Natural Key
    ProductKey INT NOT NULL, -- Foreign key to DimProduct
    ProductionCompletionDateKey INT NOT NULL, -- Foreign key to DimDate
    ProducedQuantity INT NOT NULL, -- Quantity produced
    TotalCost DECIMAL(10, 2) NOT NULL, -- Total cost of production
    p_RowVersion BINARY(8) -- Row Version method to track changes
);


-- FactSupply Table
CREATE TABLE FactSupply (
    SupplyKey INT IDENTITY(1,1) PRIMARY KEY,
	SupplyID INT NOT NULL, -- Natural Key
    --SupplierKey INT NOT NULL, -- Foreign key to DimRawMaterial
    RawMaterialKey INT NOT NULL, -- Foreign key to DimRawMaterial
    SupplyDateKey INT NOT NULL, -- Foreign key to DimDate
    Quantity INT NOT NULL, -- Quantity supplied
    Cost DECIMAL(10, 2) NOT NULL, -- Cost per unit
    TotalCost AS (Quantity * Cost) PERSISTED, -- Total cost for the supply
	s_RowVersion BINARY(8) --Row Version method to track changes
);


--1. Loading data from staging area to DimCustomer Table

INSERT INTO DimCustomer (CustomerID, FirstName, LastName, PhoneNumber, Email,Cust_RowVersion)
SELECT CustomerID, CustomerFirstName, CustomerLastName, CustomerPhoneNumber, CustomerEmail,Cust_RowVersion
FROM StagingCataschevastica.dbo.StagingCustomer;

--select * from DimCustomer

--2. Loading data from staging area to DimLogisticsPartner Table

INSERT INTO DimLogisticsPartner (LogisticID, FirstName, LastName, Email, Log_RowVersion)
SELECT LogisticID, LogPartFirstName, LogPartLastName, LogPartEmail, Log_RowVersion
FROM StagingCataschevastica.dbo.StagingLogisticsPartner;

--select * from DimLogisticsPartner

--3. Loading data from staging area to DimProdTeamMember Table

INSERT INTO DimProdTeamMember (MemberID, FirstName, LastName, Email,PTM_RowVersion)
SELECT MemberID, MemberFirstName, MemberLastName, MemberEmail,PTM_RowVersion
FROM StagingCataschevastica.dbo.StagingProdTeamMember;

--select * from DimProdTeamMember


--4. Loading data from staging area to DimProduct Table

INSERT INTO DimProduct (ProductID, ProductName, SKU, [Length], Width, Thickness, [Weight], ColorFinish, Compliance, CostPerUnit, ConstructionTime, Prod_RowVersion)
SELECT ProductID, ProductName, SKU, [Length], Width, Thickness, [Weight], ColorFinish, Compliance, CostPerUnit, ConstructionTime, Prod_RowVersion
FROM StagingCataschevastica.dbo.StagingProduct;

--select* from DimProduct

--5. Loading data from staging area to DimRawMaterial Table

INSERT INTO DimRawMaterial (RawMaterialID, RawMaterialName, MeasureUnit, SupplierFirstName, SupplierLastName, SupplierEmail, RM_RowVersion)
SELECT RawMaterialID, RawMaterialName, MeasureUnit, SupplierFirstName, SupplierLastName, SupplierEmail,RM_RowVersion
FROM StagingCataschevastica.dbo.StagingRawMaterial;

--select* from DimRawMaterial


--6. Loading data from staging area to DimDate

IF OBJECT_ID('DimDate', 'U') IS NULL
BEGIN
    CREATE TABLE DimDate (
        DateKey INT IDENTITY(1,1) PRIMARY KEY,
        Date DATE,
        Year INT,
        Quarter CHAR(1),
        Month INT,
        Day INT,
        GreekHoliday BIT DEFAULT 0
    );
END;
GO

CREATE OR ALTER FUNCTION dbo.GreekEaster (@Year INT) RETURNS DATE
AS
BEGIN
    DECLARE @A INT = @Year % 19;
    DECLARE @B INT = @Year % 4;
    DECLARE @C INT = @Year % 7;
    DECLARE @D INT = (19 * @A + 16) % 30;
    DECLARE @E INT = (2 * @B + 4 * @C + 6 * @D) % 7;
    DECLARE @DaysToEaster INT = @D + @E + 3;
    DECLARE @Easter DATE = DATEADD(DAY, @DaysToEaster, DATEFROMPARTS(@Year, 3, 21));

    RETURN @Easter;
END;
GO

-- Populate the DimDate table with all dates for the year 2024
DECLARE @StartDate DATE = '2024-01-01';
DECLARE @EndDate DATE = '2024-12-31';
DECLARE @CurrentDate DATE;

SET @CurrentDate = @StartDate;
WHILE @CurrentDate <= @EndDate
BEGIN
    IF NOT EXISTS (SELECT 1 FROM DimDate WHERE Date = @CurrentDate)
    BEGIN
        INSERT INTO DimDate (Date, Year, Quarter, Month, Day, GreekHoliday)
        VALUES (
            @CurrentDate, 
            YEAR(@CurrentDate), 
            DATEPART(QUARTER, @CurrentDate),
            MONTH(@CurrentDate), 
            DAY(@CurrentDate),
            0 -- Default to 0, update later for Greek holidays
        );
    END
    SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate);
END;
GO

-- Temporary table to hold holiday dates
CREATE TABLE #Holidays (
    HolidayDate DATE,
    HolidayName NVARCHAR(100)
);

-- Insert fixed-date holidays for 2024
INSERT INTO #Holidays (HolidayDate, HolidayName) VALUES
('2024-01-01', 'New Year''s Day'),
('2024-01-06', 'Epiphany'),
('2024-03-25', 'Independence Day'),
('2024-05-01', 'Labour Day'),
('2024-08-15', 'Assumption of the Virgin Mary'),
('2024-10-28', 'Ochi Day'),
('2024-12-25', 'Christmas Day'),
('2024-12-26', 'Synaxis of the Mother of God');

-- Calculate and insert dynamic holidays for 2024
DECLARE @Year INT = 2024;
DECLARE @Easter DATE = dbo.GreekEaster(@Year);
DECLARE @CleanMonday DATE = DATEADD(DAY, -48, @Easter);
DECLARE @GoodFriday DATE = DATEADD(DAY, -2, @Easter);
DECLARE @EasterMonday DATE = DATEADD(DAY, 1, @Easter);
DECLARE @WhitMonday DATE = DATEADD(DAY, 50, @Easter);

INSERT INTO #Holidays (HolidayDate, HolidayName) VALUES
(@CleanMonday, 'Clean Monday'),
(@GoodFriday, 'Good Friday'),
(@Easter, 'Easter Sunday'),
(@EasterMonday, 'Easter Monday'),
(@WhitMonday, 'Whit Monday');

-- Update the DimDate table to mark Greek holidays for 2024
UPDATE DimDate
SET GreekHoliday = 1
WHERE Date IN (SELECT HolidayDate FROM #Holidays);

-- Drop the temporary table
DROP TABLE #Holidays;

--select * from DimDate

--7. Load data from StagingOrderDetails to FactOrderDetails
INSERT INTO FactOrderDetails (
    CustomerKey,
    OrderDateKey,
    CompletionDateKey,
    DeliveryDateKey,
    CancellationDateKey,
    OrderID,
    OrderDetailID,
    ProductKey,
    OrderStatus,
    ProdTeamMemberKey,
    LogisticsPartnerKey,
    Quantity,
    ExtendedPriceAmount,
    Order_RowVersion
)
SELECT 
    dc.CustomerKey,
    dd.DateKey AS OrderDateKey,
    dd2.DateKey AS CompletionDateKey,
    dd3.DateKey AS DeliveryDateKey,
    dd4.DateKey AS CancellationDateKey,
    sod.OrderID,
    sod.OrderDetailID,
    dp.ProductKey,
    sod.OrderStatus,
    dptm.ProdTeamMemberKey,
    dlp.LogisticsPartnerKey,
    sod.OrderQuantity,
    sod.OrderQuantity * dp.CostPerUnit AS ExtendedPriceAmount, -- Calculate the price
    sod.Order_RowVersion
FROM 
    StagingCataschevastica.dbo.StagingOrderDetails sod
    JOIN DimCustomer dc ON sod.CustomerID = dc.CustomerID
    JOIN DimDate dd ON CAST(sod.OrderDate AS DATE) = dd.Date
    LEFT JOIN DimDate dd2 ON CAST(sod.CompletionDate AS DATE) = dd2.Date
    LEFT JOIN DimDate dd3 ON CAST(sod.DeliveryDate AS DATE) = dd3.Date
    LEFT JOIN DimDate dd4 ON CAST(sod.CancellationDate AS DATE) = dd4.Date
    JOIN DimProduct dp ON sod.ProductID = dp.ProductID
    LEFT JOIN DimProdTeamMember dptm ON sod.MemberID = dptm.MemberID
    LEFT JOIN DimLogisticsPartner dlp ON sod.LogisticID = dlp.LogisticID;


--select * from FactOrderDetails


--8. Loading data from staging area to FactProductionCompletion Table

INSERT INTO FactProductionCompletion (
    ProductionID,
    ProductKey,                 
    ProductionCompletionDateKey, 
    ProducedQuantity,           
    TotalCost,
    p_RowVersion
)
SELECT 
    stagingProd.ProductionID,
    dimProd.ProductKey,                   
    dimDate.DateKey AS ProductionCompletionDateKey, 
    stagingProd.ProducedQuantity,         
    stagingProd.TotalCost,
    stagingProd.p_RowVersion
FROM 
    StagingCataschevastica.dbo.StagingProduction stagingProd
    -- Join with product dimension table to get ProductKey
    INNER JOIN DimProduct dimProd ON stagingProd.ProductID = dimProd.ProductID
    -- Join with date dimension table to get ProductionCompletionDateKey
    INNER JOIN DimDate dimDate ON CAST(stagingProd.ProductionCompletionDate AS DATE) = dimDate.Date;

--select * from FactProductionCompletion

--9. Loading data from staging area to FactSupply Table

INSERT INTO FactSupply (SupplyID,RawMaterialKey, SupplyDateKey, Quantity, Cost, s_RowVersion)
SELECT 
    s.SupplyID,              
    rm.RawMaterialID,            
    d.DateKey,                 
    s.Quantity,
    s.Cost,
	s.s_RowVersion
FROM 
    StagingCataschevastica.dbo.StagingSupply s
    INNER JOIN StagingCataschevastica.dbo.StagingRawMaterial rm ON s.RawMaterialID = rm.RawMaterialID
    INNER JOIN DimDate d ON CAST(s.SupplyDate AS DATE) = d.Date;

--select * from FactSupply


-- Add foreign keys to FactOrderDetails
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (CustomerKey) REFERENCES DimCustomer(CustomerKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (OrderDateKey) REFERENCES DimDate(DateKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (CompletionDateKey) REFERENCES DimDate(DateKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (DeliveryDateKey) REFERENCES DimDate(DateKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (CancellationDateKey) REFERENCES DimDate(DateKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (ProdTeamMemberKey) REFERENCES DimProdTeamMember(ProdTeamMemberKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (LogisticsPartnerKey) REFERENCES DimLogisticsPartner(LogisticsPartnerKey);
ALTER TABLE FactOrderDetails ADD FOREIGN KEY (ProductKey) REFERENCES DimProduct(ProductKey);

 
-- Add foreign keys to FactProductionCompletion
ALTER TABLE FactProductionCompletion ADD FOREIGN KEY (ProductKey) REFERENCES DimProduct(ProductKey);
ALTER TABLE FactProductionCompletion ADD FOREIGN KEY (ProductionCompletionDateKey) REFERENCES DimDate(DateKey);
 
-- Add foreign keys to FactSupply
ALTER TABLE FactSupply ADD FOREIGN KEY (RawMaterialKey) REFERENCES DimRawMaterial(RawMaterialKey);
ALTER TABLE FactSupply ADD FOREIGN KEY (SupplyDateKey) REFERENCES DimDate(DateKey);


